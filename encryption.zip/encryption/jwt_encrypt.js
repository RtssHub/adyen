export default function CCEncrypt(cardData,context){
    
    const CardTypes = {
        Visa: '001',
        MasterCard: '002',
        AmericanExpress: '003',
        Discover: '004',
        Diners: '005',
        JCB: '007',
        Maestro: '042',
        ChinaUnionPay: '062',
    };

    const generateKey = (crypto) => {
        return crypto.subtle.generateKey(
            {
                name: 'AES-GCM',
                length: 256,
            },
            true,
            ['encrypt']
        );
    };

    const encrypt = async (data, context, index = 0) => {
        const crypto = new Crypto();
        const keyId = jwtDecode(context);

        const header = {
            kid: keyId.flx.jwk.kid,
            alg: 'RSA-OAEP',
            enc: 'A256GCM',
        };

        const payload = {
            data,
            context,
            index,
        };

        const iv = crypto.getRandomValues(new Uint8Array(12));

        try {
            const key = await generateKey(crypto);
            const encryptedData = await _encrypt(crypto, payload, key, header, iv);
            const builtData = await build(crypto, encryptedData[0], encryptedData[1], iv, header, keyId.flx.jwk);
            return builtData;
        } catch (error) {
            console.error('Encryption error:', error);
            return null;
        }
    };

    const _encrypt = async (crypto, payload, key, header, iv) => {
        const algorithm = {
            name: 'AES-GCM',
            iv,
            additionalData: stringToArrayBuffer(replace(JSON.stringify(header))),
            tagLength: 128,
        };

        const buffer = await crypto.subtle.encrypt(
            algorithm,
            key,
            stringToArrayBuffer(JSON.stringify(payload))
        );

        return [buffer, key];
    };

    const importKey = (crypto, jsonWebKey) => {
        return crypto.subtle.importKey(
            'jwk',
            jsonWebKey,
            {
                name: 'RSA-OAEP',
                hash: {
                    name: 'SHA-1',
                },
            },
            false,
            ['wrapKey']
        );
    };

    const wrapKey = async (crypto, key, jsonWebKey) => {
        const wrappingKey = await importKey(crypto, jsonWebKey);

        // Cast to `any` because web crypto types can be incompatible
        const params = {
            name: 'RSA-OAEP',
            hash: {
                name: 'SHA-1',
            },
        };

        return crypto.subtle.wrapKey('raw', key, wrappingKey, params);
    };

    const build = async (crypto, buffer, key, iv, header, jsonWebKey) => {
        const u = buffer.byteLength - ((128 + 7) >> 3);
        const keyBuffer = await wrapKey(crypto, key, jsonWebKey);

        return [
            replace(JSON.stringify(header)),
            replace(arrayBufferToString(keyBuffer)),
            replace(arrayBufferToString(iv)),
            replace(arrayBufferToString(buffer.slice(0, u))),
            replace(arrayBufferToString(buffer.slice(u))),
        ].join('.');
    };

    const arrayBufferToString = (buf) => {
        return String.fromCharCode.apply(null, new Uint8Array(buf));
    };

    const stringToArrayBuffer = (str) => {
        const buffer = new ArrayBuffer(str.length);
        const array = new Uint8Array(buffer);
        const { length } = str;

        for (let r = 0; r < length; r += 1) {
            array[r] = str.charCodeAt(r);
        }

        return buffer;
    };

    const replace = (str) => {
        return btoa(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    };

    // Usage example

    const determineCardType = (ccNumber) => {
        if (ccNumber.startsWith("4")) {
            return "001"; // Visa
        } else if (ccNumber.startsWith("5")) {
            return "002"; // MasterCard
        } else if (ccNumber.startsWith("3")) {
            return "003"; // AmexCard
        } else if (ccNumber.startsWith("6")) {
            return "004"; // DiscoverCard
        } else {
            return null; // Unknown card type
        }
    };

    const cardType = determineCardType(cc);
    const cardData = {
        number: cc,
        securityCode: cvv,
        expirationMonth: mes,
        expirationYear: ano,
        cardType: cardType
    };
    enc = encrypt(cardData, context)
        .then((encryptedData) => {
            // console.log('Encrypted data:', encryptedData);
            resp.json({ status: true, encrypted_value: encryptedData })
        })
        .catch((error) => {
            // console.error('Encryption error:', error);
            resp.send({ status: false, error_message: error })
        });
}