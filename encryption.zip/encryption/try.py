import requests

headers = {
    'authority': 'api.friendlycaptcha.com',
    'accept': '*/*',
    'accept-language': 'en-GB,en;q=0.8',
    'origin': 'https://andersenhitches.com',
    'referer': 'https://andersenhitches.com/',
    'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Brave";v="120"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'cross-site',
    'sec-gpc': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'x-frc-client': 'js-0.9.12',
}

params = {
    'sitekey': 'FCMMIGCST3MKLJUU',
}

response = requests.get('https://api.friendlycaptcha.com/api/v1/puzzle', params=params, headers=headers)
print(response.text)