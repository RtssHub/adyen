import express from 'express';
import bodyParser from 'body-parser';
import jwtDecode from 'jwt-decode';
import { Crypto } from '@peculiar/webcrypto';
import JSEncrypt from 'node-jsencrypt';
import btoa from 'btoa';
import crypto from 'crypto';
import jwkToPem from 'jwk-to-pem';
import NodeRSA from 'node-rsa';
import path from 'path';
import { debug } from 'console';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
// import { CCEncrypt } from '../jwt_encrypt'
// import encrypt from './ad.cjs';
// import parseKey from './ad.cjs';
import jose from 'node-jose';

const app = express();
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);



app.use(express.static(path.join(__dirname, 'public')));

app.use(bodyParser.urlencoded({ extended: true }));
app.get('/', (req, res) => {
    // Use path.join to construct the correct file path
    const filePath = path.join(__dirname, 'index.html');
    res.sendFile(filePath);
});



app.use(bodyParser.urlencoded({ extended: true }));
app.get('/v1', (req, res) => {
    const filePath = path.join(__dirname, 'public', 'cybersource_v1.html');
    res.sendFile(filePath);
});


app.get('/v1n', (req, res) => {
    const filePath = path.join(__dirname, 'public', 'cybersource_v1n.html');
    res.sendFile(filePath);
});



//  - - -- - - - - - - - - - - - - - - PAYTRACE - - - - - - - - - - - - - - - - - - - - - - - - - - //
//  - - -- - - - - - - - - - - - - - - PAYTRACE - - - - - - - - - - - - - - - - - - - - - - - - - - //
//  - - -- - - - - - - - - - - - - - - PAYTRACE - - - - - - - - - - - - - - - - - - - - - - - - - - //

app.get('/paytrace', (req, res) => {
    const filePath = path.join(__dirname, 'public', 'paytrace.html');
    res.sendFile(filePath);
});

//  - - -- - - - - - - - - - - - - - - WORLD - - - - - - - - - - - - - - - - - - - - - - - - - - //
//  - - -- - - - - - - - - - - - - - - WORLD - - - - - - - - - - - - - - - - - - - - - - - - - - //
//  - - -- - - - - - - - - - - - - - - WORLD - - - - - - - - - - - - - - - - - - - - - - - - - - //

app.get('/world', (req, res) => {
    const filePath = path.join(__dirname, 'public', 'world.html');
    res.sendFile(filePath);
});

//  - - -- - - - - - - - - - - - - - - GLOBAL - - - - - - - - - - - - - - - - - - - - - - - - - - //
//  - - -- - - - - - - - - - - - - - - GLOBAL - - - - - - - - - - - - - - - - - - - - - - - - - - //
//  - - -- - - - - - - - - - - - - - - GLOBAL - - - - - - - - - - - - - - - - - - - - - - - - - - //

app.get('/global', (req, res) => {
    const filePath = path.join(__dirname, 'public', 'global.html');
    res.sendFile(filePath);
});



//  - - -- - - - - - - - - - - - - - - SECUREPAY - - - - - - - - - - - - - - - - - - - - - - - - - - //
//  - - -- - - - - - - - - - - - - - - SECUREPAY - - - - - - - - - - - - - - - - - - - - - - - - - - //
//  - - -- - - - - - - - - - - - - - - SECUREPAY - - - - - - - - - - - - - - - - - - - - - - - - - - //

app.get('/securepay', (req, res) => {
    const filePath = path.join(__dirname, 'public', 'securepay.html');
    res.sendFile(filePath);
});



//  - - -- - - - - - - - - - - - - - - ADYEN V4 - - - - - - - - - - - - - - - - - - - - - - - - - - //
//  - - -- - - - - - - - - - - - - - - ADYEN V4 - - - - - - - - - - - - - - - - - - - - - - - - - - //
//  - - -- - - - - - - - - - - - - - - ADYEN V4 - - - - - - - - - - - - - - - - - - - - - - - - - - //

app.get('/adyen', (req, res) => {
    const filePath = path.join(__dirname, 'public', 'adyen.html');
    res.sendFile(filePath);
});


let jwtv1;
app.post('/jwtv2', (res, resp) => {
    const { context, cc, mes, ano, cvv } = res.body;

    const CardTypes = {
        Visa: '001',
        MasterCard: '002',
        AmericanExpress: '003',
        Discover: '004',
        Diners: '005',
        JCB: '007',
        Maestro: '042',
        ChinaUnionPay: '062',
    };

    const generateKey = (crypto) => {
        return crypto.subtle.generateKey(
            {
                name: 'AES-GCM',
                length: 256,
            },
            true,
            ['encrypt']
        );
    };

    const encrypt = async (data, context, index = 0) => {
        const crypto = new Crypto();
        const keyId = jwtDecode(context);

        const header = {
            kid: keyId.flx.jwk.kid,
            alg: 'RSA-OAEP',
            enc: 'A256GCM',
        };

        const payload = {
            data,
            context,
            index,
        };

        const iv = crypto.getRandomValues(new Uint8Array(12));

        try {
            const key = await generateKey(crypto);
            const encryptedData = await _encrypt(crypto, payload, key, header, iv);
            const builtData = await build(crypto, encryptedData[0], encryptedData[1], iv, header, keyId.flx.jwk);
            return builtData;
        } catch (error) {
            console.error('Encryption error:', error);
            return null;
        }
    };

    const _encrypt = async (crypto, payload, key, header, iv) => {
        const algorithm = {
            name: 'AES-GCM',
            iv,
            additionalData: stringToArrayBuffer(replace(JSON.stringify(header))),
            tagLength: 128,
        };

        const buffer = await crypto.subtle.encrypt(
            algorithm,
            key,
            stringToArrayBuffer(JSON.stringify(payload))
        );

        return [buffer, key];
    };

    const importKey = (crypto, jsonWebKey) => {
        return crypto.subtle.importKey(
            'jwk',
            jsonWebKey,
            {
                name: 'RSA-OAEP',
                hash: {
                    name: 'SHA-1',
                },
            },
            false,
            ['wrapKey']
        );
    };

    const wrapKey = async (crypto, key, jsonWebKey) => {
        const wrappingKey = await importKey(crypto, jsonWebKey);

        // Cast to `any` because web crypto types can be incompatible
        const params = {
            name: 'RSA-OAEP',
            hash: {
                name: 'SHA-1',
            },
        };

        return crypto.subtle.wrapKey('raw', key, wrappingKey, params);
    };

    const build = async (crypto, buffer, key, iv, header, jsonWebKey) => {
        const u = buffer.byteLength - ((128 + 7) >> 3);
        const keyBuffer = await wrapKey(crypto, key, jsonWebKey);

        return [
            replace(JSON.stringify(header)),
            replace(arrayBufferToString(keyBuffer)),
            replace(arrayBufferToString(iv)),
            replace(arrayBufferToString(buffer.slice(0, u))),
            replace(arrayBufferToString(buffer.slice(u))),
        ].join('.');
    };

    const arrayBufferToString = (buf) => {
        return String.fromCharCode.apply(null, new Uint8Array(buf));
    };

    const stringToArrayBuffer = (str) => {
        const buffer = new ArrayBuffer(str.length);
        const array = new Uint8Array(buffer);
        const { length } = str;

        for (let r = 0; r < length; r += 1) {
            array[r] = str.charCodeAt(r);
        }

        return buffer;
    };

    const replace = (str) => {
        return btoa(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    };

    // Usage example

    const determineCardType = (ccNumber) => {
        if (ccNumber.startsWith("4")) {
            return "001"; // Visa
        } else if (ccNumber.startsWith("5")) {
            return "002"; // MasterCard
        } else if (ccNumber.startsWith("3")) {
            return "003"; // AmexCard
        } else if (ccNumber.startsWith("6")) {
            return "004"; // DiscoverCard
        } else {
            return null; // Unknown card type
        }
    };

    const cardType = determineCardType(cc);
    const cardData = {
        number: cc,
        securityCode: cvv,
        expirationMonth: mes,
        expirationYear: ano,
        cardType: cardType
    };
    jwtv1 = encrypt(cardData, context)
        .then((encryptedData) => {
            // console.log('Encrypted data:', encryptedData);
            resp.json({ status: true, encrypted_value: encryptedData })
        })
        .catch((error) => {
            // console.error('Encryption error:', error);
            resp.send({ status: false, error_message: error })
        });

});




app.post('/v1', (req, res) => {
    const { context, cc, mes, ano, cvv } = req.body;

    function encrypt_v1(publicKey, plaintext) {
        try {
            const publicKeyPEM = `-----BEGIN PUBLIC KEY-----
${publicKey}
-----END PUBLIC KEY-----`;
            const publicKeyDER = crypto.createPublicKey(publicKeyPEM);
            const encryptedBuffer = crypto.publicEncrypt(
                {
                    key: publicKeyDER,
                    padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
                    oaepHash: 'sha256',
                },
                Buffer.from(plaintext)
            );

            const encryptedBase64 = encryptedBuffer.toString('base64');
            return encryptedBase64;
        } catch (error) {
            // Handle the error and return an appropriate response
            console.error('Encryption Error:', error);
            return null;
        }
    }

    const encryptedData = {};

    if (cc) {
        encryptedData.cc = encrypt_v1(context, cc);
        if (!encryptedData.cc) {
            return res.status(500).json({ error: 'Encryption failed for credit card number' });
        }
    }
    if (mes) {
        encryptedData.mes = encrypt_v1(context, mes);
        if (!encryptedData.mes) {
            return res.status(500).json({ error: 'Encryption failed for month' });
        }
    }
    if (ano) {
        encryptedData.ano = encrypt_v1(context, ano);
        if (!encryptedData.ano) {
            return res.status(500).json({ error: 'Encryption failed for year' });
        }
    }
    if (cvv) {
        encryptedData.cvv = encrypt_v1(context, cvv);
        if (!encryptedData.cvv) {
            return res.status(500).json({ error: 'Encryption failed for CVV' });
        }
    }

    res.json({ status: true, ...encryptedData });
});




app.post('/v1n', (req, res) => {
    const { context, cc, mes, ano, cvv } = req.body;
    const jwkData = {
        "kty": "RSA",
        "e": "AQAB",
        "use": "enc",
        "n": context
    };

    const publicKeyPEM = jwkToPem(jwkData);
    const publicKeyBase64 = publicKeyPEM
        .replace('-----BEGIN PUBLIC KEY-----\n', '')
        .replace('-----END PUBLIC KEY-----', '')
        .replace(/\n/g, '');

    function encrypt_v1(publicKey, plaintext) {

        try {
            const publicKeyPEM = `-----BEGIN PUBLIC KEY-----
${publicKey}
-----END PUBLIC KEY-----`;
            const publicKeyDER = crypto.createPublicKey(publicKeyPEM);
            const encryptedBuffer = crypto.publicEncrypt(
                {
                    key: publicKeyDER,
                    padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
                    oaepHash: 'sha256',
                },
                Buffer.from(plaintext)
            );

            const encryptedBase64 = encryptedBuffer.toString('base64');
            return encryptedBase64;
        } catch (error) {
            // Handle the error and return an appropriate response
            console.error('Encryption Error:', error);
            return null;
        }
    }

    const encryptedData = {};

    if (cc) {
        encryptedData.cc = encrypt_v1(publicKeyBase64, cc);
        if (!encryptedData.cc) {
            return res.status(500).json({ error: 'Encryption failed for credit card number' });
        }
    }
    if (mes) {
        encryptedData.mes = encrypt_v1(publicKeyBase64, mes);
        if (!encryptedData.mes) {
            return res.status(500).json({ error: 'Encryption failed for month' });
        }
    }
    if (ano) {
        encryptedData.ano = encrypt_v1(publicKeyBase64, ano);
        if (!encryptedData.ano) {
            return res.status(500).json({ error: 'Encryption failed for year' });
        }
    }
    if (cvv) {
        encryptedData.cvv = encrypt_v1(publicKeyBase64, cvv);
        if (!encryptedData.cvv) {
            return res.status(500).json({ error: 'Encryption failed for CVV' });
        }
    }

    res.json({ status: true, ...encryptedData });
});













//  - - -- - - - - - - - - - - - - - - PAYTRACE - - - - - - - - - - - - - - - - - - - - - - - - - - //
//  - - -- - - - - - - - - - - - - - - PAYTRACE - - - - - - - - - - - - - - - - - - - - - - - - - - //
//  - - -- - - - - - - - - - - - - - - PAYTRACE - - - - - - - - - - - - - - - - - - - - - - - - - - //


app.post('/paytrace', (req, res) => {
    const { context, cc, mes, ano, cvv } = req.body;

    function encrypt_v1(publicKey, plaintext) {
        try {
            const publicKeyPEM = `-----BEGIN PUBLIC KEY-----
${publicKey}
-----END PUBLIC KEY-----`;
            const publicKeyDER = crypto.createPublicKey(publicKeyPEM);
            const encryptedBuffer = crypto.publicEncrypt(
                {
                    key: publicKeyDER,
                    padding: crypto.constants.RSA_PKCS1_PADDING,
                    oaepHash: 'sha256',
                },
                Buffer.from(plaintext)
            );

            const encryptedBase64 = encryptedBuffer.toString('base64');
            return encryptedBase64;
        } catch (error) {
            // Handle the error and return an appropriate response
            console.error('Encryption Error:', error);
            return null;
        }
    }

    const encryptedData = {};

    if (cc) {
        encryptedData.cc = encrypt_v1(context, cc);
        if (!encryptedData.cc) {
            return res.status(500).json({ error: 'Encryption failed for credit card number' });
        }
    }
    if (mes) {
        encryptedData.mes = encrypt_v1(context, mes);
        if (!encryptedData.mes) {
            return res.status(500).json({ error: 'Encryption failed for month' });
        }
    }
    if (ano) {
        encryptedData.ano = encrypt_v1(context, ano);
        if (!encryptedData.ano) {
            return res.status(500).json({ error: 'Encryption failed for year' });
        }
    }
    if (cvv) {
        encryptedData.cvv = encrypt_v1(context, cvv);
        if (!encryptedData.cvv) {
            return res.status(500).json({ error: 'Encryption failed for CVV' });
        }
    }

    res.json({ status: true, ...encryptedData });
});


app.post('/world', (req, res) => {
    const { context, cc, mes, ano, cvv } = req.body;

    function encrypt_v1(publicKey, plaintext) {
        try {
            //             const publicKeyPEM = `-----BEGIN PUBLIC KEY-----
            // ${publicKey}
            // -----END PUBLIC KEY-----`;
            const publicKeyData = {
                modulus: "d68ff378fe1ce7821ef40a6d90afe8f554635b2ba86a8d47364ce60986058c21fc3a3e9a23f1b38077829f9899c9665ecc6704838fb873aa16028a63e9c5cbc01f1a72e4f433a0c68acfce9afaad09381e281eddda25b4dc713ff72b12148b1b2ad50ee830da8f1c1a70090a263bedb632df6a41a78c96c5ec41ffd9409f5723811f0b2d17597c240ec8cac893c3df5de87d1f515a8b5502cf643194b24638fd79052ac960d835a90f16e83325dbe7d0944c05d46ecfc375599d2be566b7882393fa3e03f06b653f97ab9cc33020bb637a935795b217b261c8418e64da62a58fe60c360f6165d520c5a4690caeb1f8ffe8ad0d9c62dfdbfe613c83d62586b3fd",
                exponent: "10001",
                keyId: "26356900014"
            };

            // Convert public key data to a Buffer
            const modulusBuffer = Buffer.from(publicKeyData.modulus, 'base64');
            const exponentBuffer = Buffer.from(publicKeyData.exponent, 'base64');

            const modulusBase64 = modulusBuffer.toString('base64');
            const exponentBase64 = exponentBuffer.toString('base64');
            console.log(modulusBase64)
            // Create an RSA public key object
            const keyObject = {
                key: modulusBase64,
                padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
                oaepHash: 'sha256',
            };
            
            // const publicKeyDER = crypto.createPublicKey(publicKeyPEM);
            const encryptedBuffer = crypto.publicEncrypt(
                // {
                //     key: modulusBuffer,
                //     padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
                //     oaepHash: 'sha256',},
                {
                    key: modulusBuffer,
                    padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
                    oaepHash: 'sha1',
                },
                Buffer.from(plaintext)
            );

            const encryptedBase64 = encryptedBuffer.toString('base64');
            return encryptedBase64;
        } catch (error) {
            // Handle the error and return an appropriate response
            console.error('Encryption Error:', error);
            return null;
        }
    }

    const encryptedData = {};

    if (cc) {
        encryptedData.cc = encrypt_v1(context, cc);
        if (!encryptedData.cc) {
            return res.status(500).json({ error: 'Encryption failed for credit card number' });
        }
    }
    if (mes) {
        encryptedData.mes = encrypt_v1(context, mes);
        if (!encryptedData.mes) {
            return res.status(500).json({ error: 'Encryption failed for month' });
        }
    }
    if (ano) {
        encryptedData.ano = encrypt_v1(context, ano);
        if (!encryptedData.ano) {
            return res.status(500).json({ error: 'Encryption failed for year' });
        }
    }
    if (cvv) {
        encryptedData.cvv = encrypt_v1(context, cvv);
        if (!encryptedData.cvv) {
            return res.status(500).json({ error: 'Encryption failed for CVV' });
        }
    }

    res.json({ status: true, ...encryptedData });
});


//  - - -- - - - - - - - - - - - - - - global - - - - - - - - - - - - - - - - - - - - - - - - - - //
//  - - -- - - - - - - - - - - - - - - global - - - - - - - - - - - - - - - - - - - - - - - - - - //
//  - - -- - - - - - - - - - - - - - - global - - - - - - - - - - - - - - - - - - - - - - - - - - //


app.post('/global', (req, res) => {
    const { context, cc, mes, ano, cvv } = req.body;

    function encrypt_v1(publicKey, plaintext) {
        try {
            const jsEncrypt = new JSEncrypt();
            jsEncrypt.setPublicKey(publicKey);
            const encryptedData = jsEncrypt.encrypt(plaintext);
            return encryptedData;
        } catch (error) {
            // Handle the error and return an appropriate response
            console.error('Encryption Error:', error);
            return null;
        }
    }

    const encryptedData = {};

    if (cc) {
        encryptedData.cc = encrypt_v1(context, cc);
        if (!encryptedData.cc) {
            return res.status(500).json({ error: 'Encryption failed for credit card number' });
        }
    }
    if (mes) {
        encryptedData.mes = encrypt_v1(context, mes);
        if (!encryptedData.mes) {
            return res.status(500).json({ error: 'Encryption failed for month' });
        }
    }
    if (ano) {
        encryptedData.ano = encrypt_v1(context, ano);
        if (!encryptedData.ano) {
            return res.status(500).json({ error: 'Encryption failed for year' });
        }
    }
    if (cvv) {
        encryptedData.cvv = encrypt_v1(context, cvv);
        if (!encryptedData.cvv) {
            return res.status(500).json({ error: 'Encryption failed for CVV' });
        }
    }

    res.json({ status: true, ...encryptedData });
});



//  - - -- - - - - - - - - - - - - - - SECURE PAY - - - - - - - - - - - - - - - - - - - - - - - - - - //
//  - - -- - - - - - - - - - - - - - - SECURE PAY - - - - - - - - - - - - - - - - - - - - - - - - - - //
//  - - -- - - - - - - - - - - - - - - SECURE PAY - - - - - - - - - - - - - - - - - - - - - - - - - - //


app.post('/securepay', (req, res) => {
    const { context, cc, mes, ano, cvv } = req.body;

    function encrypt_securepay(publicKey, plaintext) {
        try {
            const pemPublicKey = `
-----BEGIN PUBLIC KEY-----
${publicKey}
-----END PUBLIC KEY-----
`;

            const Key = new NodeRSA(pemPublicKey);
            const encryptedData = Key.encrypt(plaintext, 'base64');
            return encryptedData;
        } catch (error) {
            console.error('Encryption Error:', error);
            return null;
        }
    }

    const encryptedData = {};

    if (cc) {
        encryptedData.cc = encrypt_securepay(context, cc);
        if (!encryptedData.cc) {
            return res.status(500).json({ error: 'Encryption failed for credit card number' });
        }
    }
    if (mes) {
        encryptedData.mes = encrypt_securepay(context, mes);
        if (!encryptedData.mes) {
            return res.status(500).json({ error: 'Encryption failed for month' });
        }
    }
    if (ano) {
        encryptedData.ano = encrypt_securepay(context, ano);
        if (!encryptedData.ano) {
            return res.status(500).json({ error: 'Encryption failed for year' });
        }
    }
    if (cvv) {
        encryptedData.cvv = encrypt_securepay(context, cvv);
        if (!encryptedData.cvv) {
            return res.status(500).json({ error: 'Encryption failed for CVV' });
        }
    }

    res.json({ status: true, ...encryptedData });
});









//  - - -- - - - - - - - - - - - - - - ADYEN - - - - - - - - - - - - - - - - - - - - - - - - - - //
//  - - -- - - - - - - - - - - - - - - ADYEN - - - - - - - - - - - - - - - - - - - - - - - - - - //
//  - - -- - - - - - - - - - - - - - - ADYEN - - - - - - - - - - - - - - - - - - - - - - - - - - //


app.post('/adyen', (req, res) => {
    const { context, cc, mes, ano, cvv } = req.body;
    // async function encrypt_adyen(publicKey) {
    //     try {
    //         const Key = await parseKey("10001|E9299A45B34AE878855F3E66136B461664F519E85F36E59B505CD6590311FE96BAF50830BED460FE6EB8AD39B3E4BFCF5028A33A64C518E3BC13F23E49CE9C68B13A3ED9BB9233C166A7572755E62CB67AAF7A6AFC1070CAD7FF3F6FD8C070168FC6ED31E81F3DE10A93D6A9494F9D24900F1499D95264E66E3DC357B4628E02A6DF0ED37196539309AB0B1EA7EEB2BD67452B16289452D617C687867981C3570E0C43C51EB273154011D53F09B2B2E1AAD41B13B686A861D2C095DFEA258AD589AE482CAF9B05EFFF1C16EF182D67CA459B6EBD00E63F170307B56237A6C8AE593EFAD9E58AEC7D560B41B3412DD7D5E64B76BFEF75354DC52BD2138B77F279");//await jose.JWK.createKey("RSA", 2048);

    //         const generationTime = new Date;
    //         const encryptedData = await Promise.all([
    //             encrypt(Key, "number", cc, generationTime),
    //             encrypt(Key, "expiryMonth", mes, generationTime),
    //             encrypt(Key, "expiryYear", ano, generationTime),
    //             encrypt(Key, "cvc", cvv, generationTime)
    //         ]);
    //         console.log(encryptedData)
    //         return encryptedData;
    //     } catch (error) {
    //         console.error('Encryption Error:', error);
    //         return null;
    //     }
    // }
    async function parseKey(t) {
        // These two functions can probably be replaced with something cleaner
        // to: URL-safe base64 encode?
        // ro: hex decode
        function to(e) {
            return function (e) {
                var t = e;
                for (var r = [], n = 0; n < t.length; n += 32768)
                    r.push(String.fromCharCode.apply(null, t.subarray(n, n + 32768)));
                return btoa(r.join(""))
            }(e).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_")
        }

        function ro(e) {
            if (!e)
                return new Uint8Array(0);
            e.length % 2 == 1 && (e = "0" + e);
            for (var t = e.length / 2, r = new Uint8Array(t), n = 0; n < t; n++)
                r[n] = parseInt(e.substr(2 * n, 2), 16);
            return r
        }

        const r = t.split("|"); // Key parts
        const n = r[0]; // Exponent
        const o = r[1]; // RSA public key
        const i = ro(n);
        const a = ro(o);
        const c = to(i);
        const s = to(a);

        return jose.JWK.asKey({
            kty: "RSA",
            kid: "asf-key", // kid used in Adyen script
            e: c,
            n: s
        });
    }

    // Encrypt fieldName with value and generationTime with the given pubKey
    // Valid field names:
    // - number
    // - expiryMonth
    // - expiryYear
    // - cvc
    async function encrypt(pubKey, fieldName, value, generationTime) {
        // ISO string without milliseconds
        const formattedGenerationTime = generationTime.toISOString().split('.')[0] + "Z";

        let data;
        switch (fieldName) {
            case "number":
                data = {
                    "number": value,
                    "activate": "3",
                    "deactivate": "1",
                    "generationtime": formattedGenerationTime,
                    "numberBind": "1",
                    "numberFieldBlurCount": "1",
                    "numberFieldClickCount": "1",
                    "numberFieldFocusCount": "3",
                    "numberFieldKeyCount": "2",
                    "numberFieldLog": "fo@5956,cl@5960,bl@5973,fo@6155,fo@6155,Md@6171,KL@6173,pa@6173",
                    "numberFieldPasteCount": "1",
                    "referrer": "https://checkoutshopper-live.adyen.com/checkoutshopper/securedfields/live_DY4VMYQL5ZHXXE5NLG4RA5PYKYWDYAU2/4.5.0/securedFields.html?type=card&d=aHR0cHM6Ly9jaGVsc2VhZmMuM2RkaWdpdGFsdmVudWUuY29t"
                };
                break;

            case "expiryMonth":
                data = {
                    "expiryMonth": value,
                    "generationtime": formattedGenerationTime
                };
                break;

            case "expiryYear":
                data = {
                    "expiryYear": value,
                    "generationtime": formattedGenerationTime
                };
                break;

            case "cvc":
                data = {
                    "activate": "1",
                    "cvc": value,
                    "cvcBind": "1",
                    "cvcFieldClickCount": "1",
                    "cvcFieldFocusCount": "2",
                    "cvcFieldKeyCount": "4",
                    "cvcFieldLog": "fo@20328,fo@20328,cl@20329,KN@20344,KN@20347,KN@20349,KN@20351",
                    "generationtime": formattedGenerationTime,
                    "referrer": "https://checkoutshopper-live.adyen.com/checkoutshopper/securedfields/live_DY4VMYQL5ZHXXE5NLG4RA5PYKYWDYAU2/4.5.0/securedFields.html?type=card&d=aHR0cHM6Ly9jaGVsc2VhZmMuM2RkaWdpdGFsdmVudWUuY29t"
                };
                break;

            default:
                throw new Error("Invalid fieldName " + fieldName);
        }

        return jose.JWE.createEncrypt(
            {
                format: "compact",
                contentAlg: "A256CBC-HS512",
                fields: {
                    alg: "RSA-OAEP",
                    enc: "A256CBC-HS512",
                    version: "1" // additional field added by Adyen
                }
            },
            { key: pubKey, reference: false } // don't include "kid" field in header
        )
            .update(JSON.stringify(data))
            .final();
    }
    async function useme(context) {
        const key = await parseKey(context);//await jose.JWK.createKey("RSA", 2048);
        const generationTime = new Date;
        const encrypted_data = await Promise.all([
            encrypt(key, "number", cc, generationTime),
            encrypt(key, "expiryMonth", mes, generationTime),
            encrypt(key, "expiryYear", ano, generationTime),
            encrypt(key, "cvc", cvv, generationTime)
        ]);

        return encrypted_data;
    }

    adyenj = useme(context)
        .then((encrypted_data) => {
            // console.log('Encrypted data:', encryptedData);
            res.json({ status: true, encryptedCardNumber: encrypted_data[0], encryptedSecurityCode: encrypted_data[3], encryptedExpiryYear: encrypted_data[2], encryptedExpiryMonth: encrypted_data[1] })
        })
        .catch((error) => {
            // console.error('Encryption error:', error);
            res.send({ status: false, error_message: error })
        });

});

let adyenj;














app.listen(3000,)