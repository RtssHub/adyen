const User = require('../models/user');

async function authenticate(req, res, next) {
    next(); 
}

module.exports = authenticate;