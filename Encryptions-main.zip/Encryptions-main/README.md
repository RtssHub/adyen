# Gateway Encryptions

This is an encryptor for gateways.

## Setup Instructions

To run this project perfectly, follow the steps below:

1. Open the file:
  src/db/connection.js
2. Replace `<MONGO URL>` with your actual Database URL:
```javascript
await mongoose.connect('<MONGO URL>/SiteDB', {});
```

Made by [@bloodtools](https://t.me/bloodtools) and [@bruxo_dev77](https://t.me/bruxo_dev77)
## License

This project is licensed under the [MIT](https://choosealicense.com/licenses/mit/) License. Feel free to use and modify the code as needed.
## Authors
